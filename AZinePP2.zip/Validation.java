package PP2;

public class Validation {

  // Return true if the card number is valid, otherwise returns false, this method is already implemented
  public boolean aValidNumber(String n) {

	long number = Long.parseLong(n);
	return  (numLength(number) >= 13) && (numLength(number) <= 16) &&
        (prefixCheck(number, 4) || prefixCheck(number, 5) ||
        prefixCheck(number, 6) || prefixCheck(number, 37)) &&
        (totalEevenNumbers(number) + totalOddNumbers(number)) % 10 == 0;
  }// end of aValidNumber method

  //get the sum of even places numbers, Starting from the second digit from right
  private int totalEevenNumbers(long number) 
  {
	  long remainder = number / 10;
	  int sumOfDigits = 0;
	  
	  while (remainder > 0) 
	  {
		  // Extract a single digit and double it
		  int doubledDigit = 2 * (int) (remainder % 10);
			
		  // Compute sum of double digits
		  sumOfDigits += singleDigit(doubledDigit);
			
		  // Get rid of current digit and next digit (since it will be odd)
		  remainder = remainder / 100;
	  }

	  return sumOfDigits;
  }// end of totalEevenNumbers method

  // Return the same number if it is a single digit, otherwise, return the sum of
  // the two digits in this number
  private int singleDigit(int number) 
  {
	  int result = 0;

		// If number is less than 10, return number. Otherwise, set result to the sum of the digits.
		if (number < 10) {
			result = number;
		} 
		else 
		{  
			result = (number / 10) + (number % 10);
		}

		return result;
  } // end of singleDigit method



  // Return the sum of odd place digits in number
  private int totalOddNumbers(long number) 
  {
	  long remainder = number;
	  int sumOfDigits = 0;

	  while (remainder > 0) 
	  {
		  // Extract a single digit
		  sumOfDigits += (int) (remainder % 10);
			
		  // Get rid of current digit and next digit (since it's even)
		  remainder = remainder / 100;
	  }

	  return sumOfDigits;

  }// end of totalOddNumbers method

  // Return true if the digit d is a prefix for number
  private boolean prefixCheck(long number, int d) 
  {
	  long check = numPrefix(number, numLength(d));
	  return check == d;
  }// end of prefixCheck method


  // Return the number of digits in this number parameter
  private int numLength(long number) 
  {
	  // Concatenate num into a string and return length of string
	  String num = number + "";
	  return num.length();
  }// end of numLength method

  // Return the first k number of digits from number, which is either a first digit or first two digits
  // Depending on the card type
  private long numPrefix(long number, int k) 
  {
	  if (numLength(number) > k) 
	  { 
          String num = number + ""; 
          // Parse beginning of the string num, specified by the substring starting at index 0 until the entered parameter k
          return Long.parseLong(num.substring(0, k)); 
      } 
	  
      return number;
  }// end of numPrefix method

}// end of the class
