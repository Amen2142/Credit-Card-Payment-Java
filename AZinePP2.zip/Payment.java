package PP2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class Payment {

	public static Validation validating;
	public static HashCode hashing;
	public static Customer[] customers;
	
	// isLetter() method
	private static boolean isLetter(String number) {
		
		return false;
	}
	
	// this will check whether a card is valid
	public static Boolean isValidCard(String number){
		
		if (validating.aValidNumber(number) == true) {
			
			return true;
		}
		
		else 		
			return false;
	
		
	
	}// end of the isValidCard method

	// creates a hash code for the credit card number to be stored in file
    public static String createHashCode(String number){
    	
    	String hashCode = 	hashing.getHashCode(number);

		return hashCode;

	}// end of the createHashCode method


     // it adds a new customer to the array of customers once the payment was successful
 	 public static void addCustomer(Customer customer){
 		 
 		 customers[customers.length-1] = customer;

 	 } // end of the addCustomer method


	// it displays the payments AVG, MAX payment, and MIN payment,
	// only for accepted payments with valid cards
	public static void displayStat(){

		
			double total = 0;
			double max = customers[0].getAmount();
			double min = customers[0].getAmount();
			
			if (customers.length == 0)
				return;
			
			for (int i = 0; i < customers.length; i++) {
			
				total += customers[i].getAmount();
				
				if (max < customers[i].getAmount())
					max = customers[i].getAmount();
				
				if (min > customers[i].getAmount())
					min = customers[i].getAmount();
				
			} // End for
			
			String out = "Average:\t\t$" + String.format("%.2f", total / customers.length) + 
					"\nHighest payment:\t$" + String.format("%.2f", max) +
					"\nLowest payment:\t$" + String.format("%.2f", min) + "\n";
			
			for (int i = 0; i < customers.length; i++)
				out += customers[i].toString() + "\n";
			
			JOptionPane.showMessageDialog(null, new JTextArea(out));
	
	}// end of the displayStat method


	// write data to file, the credit card number should be encrypted
	// using one-way hash method in the Hashing class
    public static void writeToFile() throws FileNotFoundException{
    	
    	// Create a file
    	File file = new File ("Customer.txt");
    	
    	String output = "";
    	
    	for (int i = 0; i < customers.length; i++) {
    		
    		String number = String.valueOf(customers[i].getCard().getNumber());
    		String cust = customers[i].toString();
    		cust = cust.replace(number, hashing.getHashCode(number));
    		
    		output += cust + "\r\n";
    	}
    	
    	// Write to the file
    	PrintWriter write = new PrintWriter(file);
 
    	write.print(output);
    	
    	// Close the file
    	write.close();
    	
    	JOptionPane.showMessageDialog(null, "Completed writing data to file \"Customer.txt\"");

    } // end of the writeToFile method


	// the main entry method of the program that will get data from user and
	// perform the business logic
	public static void main(String[] args) throws FileNotFoundException {

		hashing = new HashCode();
		validating = new  Validation();                     
		int n = 0;
		int id;
		String fName, lName;
		double amount;
		String expDate;
		
		try {
		
		n = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the number of customers: ", "Number of Customers",
				JOptionPane.INFORMATION_MESSAGE));
		
		if (n <= 0)
			throw new Exception();
		
		customers = new Customer[n];
		
		} catch (Exception E) {
			
			JOptionPane.showMessageDialog(null, "Invalid Input - Exit?", "Number of Customers", JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
		}
		
		try {
			
			for (int i = 0; i < n; i++) {
								
				
		String number;
	
		number = JOptionPane.showInputDialog(null, "Please enter a credit card number as a long integer: ", "Card Numbers",
				JOptionPane.INFORMATION_MESSAGE);
		
		if (number.isBlank() && isLetter(number) == false) {

			JOptionPane.showMessageDialog(null, "Invalid Input - Exit?", "Card Numbers", JOptionPane.WARNING_MESSAGE);
			System.exit(0);
		}
		
		
		// Call method isValidCard()
		boolean validCard;
		
		validCard = isValidCard(number);
		
		if (validCard == true) {
			
			JOptionPane.showMessageDialog(null, "The credit card number:\n" + number + " is valid", "Card Numbers", 
					JOptionPane.INFORMATION_MESSAGE);			
		} // end if
		
		else if (validCard == false)	{		
			JOptionPane.showMessageDialog(null, "The credit card number:\n" + number + " is invalid", "Card Numbers", 
					JOptionPane.WARNING_MESSAGE);
			JOptionPane.showMessageDialog(null, "Please enter the correct credit card number!", "Card Numbers", 
					JOptionPane.WARNING_MESSAGE);
			System.exit(0);
		}
		
		// add customers payments information
		
						
				id = Integer.parseInt(JOptionPane.showInputDialog(null, "Please enter the customer ID: ", "Customer Information",
						JOptionPane.INFORMATION_MESSAGE));
				
				if (id < 0) {
					JOptionPane.showMessageDialog(null, "Invalid Input - Exit?", "Customer Information", JOptionPane.WARNING_MESSAGE);
					System.exit(0);
				}
				
			
			if (id == 0) {
				throw new Exception();
			}
		
		fName = JOptionPane.showInputDialog(null, "Please enter the customer's First Name: ", "Customer Information",
				JOptionPane.INFORMATION_MESSAGE);
			if (fName.isBlank()) {
				JOptionPane.showMessageDialog(null, "Invalid Input! - Exit?", "Customer Information", 
						JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
			}
		
		lName = JOptionPane.showInputDialog(null, "Please enter the customer's Last Name: ", "Customer Information",
				JOptionPane.INFORMATION_MESSAGE);
			if (lName.length() <= 0) {
				JOptionPane.showMessageDialog(null, "Invalid Input! - Exit?", "Customer Information", 
						JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
			}
		
		amount = Double.parseDouble(JOptionPane.showInputDialog(null, "Please enter the amount of money: ", "Customer Information",
				JOptionPane.INFORMATION_MESSAGE)); 
			if (amount <= 0) {
				JOptionPane.showMessageDialog(null, "Invalid Input! - Exit?", "Customer Information", 
						JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);
			}
		
		expDate = JOptionPane.showInputDialog(null, "Please enter the expiration date of card: ", "Customer Information",
				JOptionPane.INFORMATION_MESSAGE);
		
		long num = Long.parseLong(number);
		
		// Create an object	
			
		customers[i] = new Customer(fName, lName, id, amount, new CreditCard(num, expDate));
		
		addCustomer(customers[i]);
		
			if (i == customers.length) {
				JOptionPane.showMessageDialog(null, "Complete to add customer information!", "Customer Information", 
						JOptionPane.INFORMATION_MESSAGE);
				break;
			}
			
		} // end for
		
		} catch (Exception Ex) {
			
			JOptionPane.showMessageDialog(null, "Complete to add customer information!", "Customer Information", 
					JOptionPane.INFORMATION_MESSAGE);
			System.exit(0);

			} // end catch
	
		
		// Call method displayStat() to display the payments AVG, MAX payment, and MIN payment
		displayStat();	
		
		// Call method writeToFile() to write data to file
		writeToFile();
		
	} // end main	

} // end class
